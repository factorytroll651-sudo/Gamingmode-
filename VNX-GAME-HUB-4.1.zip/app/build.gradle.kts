plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vnx.gamehub"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vnx.gamehub"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "4.1"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
