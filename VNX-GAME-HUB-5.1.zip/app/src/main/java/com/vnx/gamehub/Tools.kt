package com.vnx.gamehub

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.pm.ApplicationInfo
import android.media.AudioManager
import android.view.WindowManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vnx", Context.MODE_PRIVATE)

    fun getInt(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun getBool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun getLong(c: Context, k: String, d: Long) = sp(c).getLong(k, d)
    fun putLong(c: Context, k: String, v: Long) = sp(c).edit().putLong(k, v).apply()
    fun getStr(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    const val DEFAULT_SENSI =
        "General=190\nRed Dot=180\n2x Scope=170\n4x Scope=160\nAWM Scope=110\nFree Look=150"
}

/** Every tool returns a short report string that the UI prints in its console. */
object Tools {
    private const val ADB_HINT =
        "needs one-time ADB: adb shell pm grant com.vnx.gamehub android.permission.WRITE_SECURE_SETTINGS"

    fun gameOn(c: Context): String {
        val sb = StringBuilder("GAME MODE ON\n")
        val cr = c.contentResolver
        if (Settings.System.canWrite(c)) {
            try {
                Prefs.putInt(c, "prev_bmode", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 1))
                Prefs.putInt(c, "prev_rot", Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1))
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 255)
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
                sb.append("[OK] Brightness MAX | Rotation LOCKED\n")
            } catch (e: Exception) {
                sb.append("[X] Display: ").append(e.message).append('\n')
            }
        } else sb.append("[X] Display: grant 'Modify system settings' first\n")

        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            Prefs.putInt(c, "prev_filter", nm.currentInterruptionFilter)
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            sb.append("[OK] Do Not Disturb ON\n")
        } else sb.append("[X] DND: grant Do Not Disturb access first\n")
        Prefs.putBool(c, "game_on", true)
        return sb.toString().trim()
    }

    fun gameOff(c: Context): String {
        val sb = StringBuilder("GAME MODE OFF\n")
        val cr = c.contentResolver
        if (Settings.System.canWrite(c)) {
            try {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Prefs.getInt(c, "prev_bmode", 1))
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, Prefs.getInt(c, "prev_rot", 1))
                sb.append("[OK] Auto brightness | Rotation restored\n")
            } catch (e: Exception) {
                sb.append("[X] Display: ").append(e.message).append('\n')
            }
        } else sb.append("[X] Display: grant 'Modify system settings' first\n")

        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(
                Prefs.getInt(c, "prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL)
            )
            sb.append("[OK] Do Not Disturb restored\n")
        } else sb.append("[X] DND: grant Do Not Disturb access first\n")
        Prefs.putBool(c, "game_on", false)
        return sb.toString().trim()
    }

    fun gameToggle(c: Context): String =
        if (Prefs.getBool(c, "game_on", false)) gameOff(c) else gameOn(c)

    fun boost(c: Context, on: Boolean): String {
        val v = if (on) 0.5f else 1.0f
        val cr = c.contentResolver
        return try {
            Settings.Global.putFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, v)
            Settings.Global.putFloat(cr, Settings.Global.TRANSITION_ANIMATION_SCALE, v)
            Settings.Global.putFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, v)
            if (on) "PERFORMANCE BOOST\n[OK] Animation scale 0.5x"
            else "PERFORMANCE RESET\n[OK] Animation scale 1.0x"
        } catch (e: SecurityException) {
            "[X] Animation scale $ADB_HINT"
        }
    }

    fun touches(c: Context, on: Boolean): String = try {
        Settings.System.putInt(c.contentResolver, "show_touches", if (on) 1 else 0)
        if (on) "[OK] Touch points VISIBLE" else "[OK] Touch points HIDDEN"
    } catch (e: Exception) {
        "[X] Show touches $ADB_HINT"
    }

    fun tcpPing(host: String, port: Int): String {
        val t0 = System.nanoTime()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), 2000) }
            "${(System.nanoTime() - t0) / 1_000_000} ms"
        } catch (e: Exception) {
            "FAIL"
        }
    }

    fun system(c: Context): String {
        val am = c.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        return "SYSTEM CHECK\n" +
            "Device : ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "RAM    : ${mi.availMem / 1048576} / ${mi.totalMem / 1048576} MB free\n" +
            "Battery: ${if (lvl >= 0) lvl * 100 / sc else 0}%  ${temp}C\n" +
            "Ping   : ${tcpPing("8.8.8.8", 53)}"
    }

    fun network(): String =
        "NETWORK DIAG\n" +
            "8.8.8.8    : ${tcpPing("8.8.8.8", 53)}\n" +
            "1.1.1.1    : ${tcpPing("1.1.1.1", 53)}\n" +
            "google.com : ${tcpPing("google.com", 443)}"

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

    fun sessionStart(c: Context): String {
        Prefs.putLong(c, "sess_start", System.currentTimeMillis())
        appendLog(c, "${now()} START")
        return "SESSION STARTED"
    }

    fun sessionStats(c: Context): String {
        val s = Prefs.getLong(c, "sess_start", 0L)
        val total = Prefs.getStr(c, "sess_log", "").lines().count { it.contains("START") }
        val run = if (s > 0) "${(System.currentTimeMillis() - s) / 60000} MIN" else "NO ACTIVE SESSION"
        return "SESSION STATS\nRunning : $run\nTotal   : $total sessions"
    }

    fun sessionEnd(c: Context): String {
        val s = Prefs.getLong(c, "sess_start", 0L)
        if (s <= 0) return "NO ACTIVE SESSION"
        val m = (System.currentTimeMillis() - s) / 60000
        appendLog(c, "${now()} END $m MIN")
        Prefs.putLong(c, "sess_start", 0L)
        return "SESSION ENDED: $m MIN"
    }

    private fun appendLog(c: Context, line: String) {
        val all = (Prefs.getStr(c, "sess_log", "").lines().filter { it.isNotBlank() } + line).takeLast(60)
        Prefs.putStr(c, "sess_log", all.joinToString("\n"))
    }

    fun sensi(c: Context): String {
        val rows = Prefs.getStr(c, "sensi", Prefs.DEFAULT_SENSI).lines().filter { it.contains("=") }
        return "SENSI PRESETS (your in-game values)\n" + rows.joinToString("\n") {
            val p = it.split("=", limit = 2)
            p[0].trim().padEnd(10) + " " + p[1].trim()
        }
    }

    fun boostToggle(c: Context): String {
        val on = !Prefs.getBool(c, "boost_on", false)
        val r = boost(c, on)
        if (!r.startsWith("[X]")) Prefs.putBool(c, "boost_on", on)
        return r
    }

    fun touchesToggle(c: Context): String {
        val on = !Prefs.getBool(c, "touches_on", false)
        val r = touches(c, on)
        if (r.startsWith("[OK]")) Prefs.putBool(c, "touches_on", on)
        return r
    }

    fun sessionToggle(c: Context): String =
        if (Prefs.getLong(c, "sess_start", 0L) > 0L) sessionEnd(c) else sessionStart(c)

    fun brightness(c: Context, pct: Int): String {
        if (!Settings.System.canWrite(c)) return "[X] grant 'Modify system settings' first"
        return try {
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (pct * 255 / 100).coerceIn(1, 255))
            "BRIGHTNESS $pct%"
        } catch (e: Exception) { "[X] ${e.message}" }
    }

    // ---------- Free Fire detection ----------

    private val ffCache = HashMap<String, Boolean>()
    private val ffKnown = setOf("com.dts.freefireth", "com.dts.freefiremax",
        "com.garena.game.fireindia", "com.garena.game.ffin")

    fun isFreeFire(c: Context, pkg: String): Boolean {
        if (pkg in ffKnown) return true
        return ffCache.getOrPut(pkg) {
            try {
                val pm = c.packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString().lowercase().contains("free fire")
            } catch (e: Exception) { false }
        }
    }

    fun hasUsageAccess(c: Context): Boolean {
        val ops = c.getSystemService(AppOpsManager::class.java)
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Last app that came to the foreground in the past 20 seconds, or null if nothing changed. */
    fun foregroundPkg(c: Context): String? {
        val usm = c.getSystemService(UsageStatsManager::class.java) ?: return null
        val end = System.currentTimeMillis()
        val ev = usm.queryEvents(end - 20_000, end) ?: return null
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            @Suppress("DEPRECATION")
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    // ---------- Performance ----------

    fun refreshList(c: Context): List<Int> {
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        val l = wm.defaultDisplay.supportedModes.map { it.refreshRate.toInt() }.distinct().sorted()
        return if (l.isEmpty()) listOf(60) else l
    }

    fun maxRefresh(c: Context): Int = refreshList(c).last()

    fun setRefreshRange(c: Context, minHz: Int, peakHz: Int): String = try {
        Settings.System.putFloat(c.contentResolver, "min_refresh_rate", minHz.toFloat())
        Settings.System.putFloat(c.contentResolver, "peak_refresh_rate", peakHz.toFloat())
        "[OK] Refresh request: " + (if (minHz == peakHz) "$minHz Hz fixed" else "auto up to $peakHz Hz") +
            " (some phones ignore this)"
    } catch (e: Exception) {
        "[X] Refresh rate: allow 'Modify system settings' first"
    }

    fun setRefresh(c: Context, hz: Int): String {
        Prefs.putInt(c, "refresh_hz", hz)
        return if (hz <= 0) setRefreshRange(c, 0, maxRefresh(c)) else setRefreshRange(c, hz, hz)
    }

    fun cleanRam(c: Context): String {
        val am = c.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val before = mi.availMem
        var n = 0
        for (ai in c.packageManager.getInstalledApplications(0)) {
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            if (ai.packageName == c.packageName || isFreeFire(c, ai.packageName)) continue
            try { am.killBackgroundProcesses(ai.packageName); n++ } catch (e: Exception) { }
        }
        Thread.sleep(700)
        am.getMemoryInfo(mi)
        val freed = maxOf(0L, (mi.availMem - before) / 1048576)
        return "[OK] Closed $n background apps | RAM freed ~$freed MB | free now ${mi.availMem / 1048576} MB"
    }

    /** mode 0 = battery saver, 1 = balanced, 2 = BOOST (maximum). */
    fun setMode(c: Context, mode: Int): String {
        Prefs.putInt(c, "perf_mode", mode)
        Prefs.putBool(c, "boost_on", mode == 2)
        val sb = StringBuilder(when (mode) { 0 -> "MODE: BATTERY SAVER"; 1 -> "MODE: BALANCED"; else -> "MODE: BOOST (MAX)" }).append('\n')
        val scale = when (mode) { 0 -> 1.0f; 1 -> 0.5f; else -> 0.0f }
        val cr = c.contentResolver
        try {
            Settings.Global.putFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, scale)
            Settings.Global.putFloat(cr, Settings.Global.TRANSITION_ANIMATION_SCALE, scale)
            Settings.Global.putFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, scale)
            sb.append("[OK] Animations ${scale}x\n")
        } catch (e: SecurityException) {
            sb.append("[X] Animations $ADB_HINT\n")
        }
        val max = maxRefresh(c)
        sb.append(when (mode) {
            0 -> setRefreshRange(c, 0, 60)
            1 -> setRefreshRange(c, 0, max)
            else -> setRefreshRange(c, max, max)
        }).append('\n')
        if (Settings.System.canWrite(c)) {
            try {
                Settings.System.putInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, if (mode == 2) 1_800_000 else 60_000)
                sb.append("[OK] Screen-off ${if (mode == 2) "30" else "1"} min\n")
            } catch (e: Exception) { }
        }
        if (mode == 2) sb.append(cleanRam(c))
        return sb.toString().trim()
    }

    fun esports(c: Context, on: Boolean): String {
        val a = if (on) gameOn(c) else gameOff(c)
        val b = setMode(c, if (on) 2 else 1)
        Prefs.putBool(c, "esports_on", on)
        return a + "\n" + b
    }

    fun esportsToggle(c: Context): String = esports(c, !Prefs.getBool(c, "esports_on", false))

    fun dndToggle(c: Context): String {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return "[X] grant Do Not Disturb access first"
        val on = !Prefs.getBool(c, "dnd_on", false)
        if (on) {
            Prefs.putInt(c, "prev_filter", nm.currentInterruptionFilter)
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        } else {
            nm.setInterruptionFilter(Prefs.getInt(c, "prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL))
        }
        Prefs.putBool(c, "dnd_on", on)
        return if (on) "[OK] Notifications BLOCKED" else "[OK] Notifications restored"
    }

    fun brightLockToggle(c: Context): String {
        if (!Settings.System.canWrite(c)) return "[X] grant 'Modify system settings' first"
        val on = !Prefs.getBool(c, "bright_lock", false)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, if (on) 0 else 1)
        Prefs.putBool(c, "bright_lock", on)
        return if (on) "[OK] Brightness LOCKED (auto-dim off)" else "[OK] Auto brightness back"
    }

    fun rotLockToggle(c: Context): String {
        if (!Settings.System.canWrite(c)) return "[X] grant 'Modify system settings' first"
        val on = !Prefs.getBool(c, "rot_lock", false)
        Settings.System.putInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 0 else 1)
        Prefs.putBool(c, "rot_lock", on)
        return if (on) "[OK] Rotation LOCKED" else "[OK] Rotation free"
    }

    fun volumeMax(c: Context): String {
        val am = c.getSystemService(AudioManager::class.java)
        val m = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, m, 0)
        return "[OK] Media volume MAX ($m/$m)"
    }

    fun gameMinutes(c: Context): Long {
        val s = Prefs.getLong(c, "sess_start", 0L)
        return if (s > 0) (System.currentTimeMillis() - s) / 60000 else 0L
    }

    fun ramUsedPct(c: Context): Int {
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return if (mi.totalMem > 0) (100 - mi.availMem * 100 / mi.totalMem).toInt() else 0
    }

    fun batteryPct(c: Context): Int {
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l >= 0) l * 100 / s else 0
    }

    fun batteryTemp(c: Context): Double =
        (c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
}
