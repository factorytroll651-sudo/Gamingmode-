package com.vnx.gamehub

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** White pill switch with a black knob (off) that turns purple with a white knob (on). */
class PillSwitch(ctx: Context) : View(ctx) {
    var onChange: ((Boolean) -> Unit)? = null
    private var checked = false
    private var pos = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    fun setChecked(v: Boolean, animate: Boolean = true) {
        checked = v
        val t = if (v) 1f else 0f
        if (!animate) { pos = t; invalidate(); return }
        animate().cancel()
        val start = pos
        android.animation.ValueAnimator.ofFloat(start, t).apply {
            duration = 160
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun isOn() = checked

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(54), context.dp(30))

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = if (pos > 0.5f) Theme.PURPLE else Color.WHITE
        box.set(0f, 0f, w, h)
        c.drawRoundRect(box, h / 2, h / 2, p)
        p.color = if (pos > 0.5f) Color.WHITE else Color.BLACK
        val kr = h / 2 - context.dpf(4f)
        c.drawCircle(h / 2 + pos * (w - h), h / 2, kr, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            setChecked(!checked, true); onChange?.invoke(checked)
        }
        return true
    }
}

object Sen {
    val PANEL = Color.parseColor("#141414")

    /** Outlined purple card, like the sections in the reference screens. */
    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(c.dp(16), c.dp(14), c.dp(16), c.dp(14))
        background = GradientDrawable().apply {
            cornerRadius = c.dpf(24f); setColor(Color.TRANSPARENT); setStroke(c.dp(2), Theme.PURPLE)
        }
    }

    fun panel(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(c.dp(16), c.dp(10), c.dp(16), c.dp(10))
        background = GradientDrawable().apply { cornerRadius = c.dpf(20f); setColor(PANEL) }
    }

    fun title(c: Context, text: String): TextView = TextView(c).apply {
        this.text = text; textSize = 16f; setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setPadding(c.dp(2), c.dp(14), 0, c.dp(8))
    }

    fun switchRow(c: Context, label: String, on: Boolean, change: (Boolean) -> Unit): Pair<LinearLayout, PillSwitch> {
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, c.dp(12), 0, c.dp(12))
        }
        row.addView(TextView(c).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = PillSwitch(c)
        sw.setChecked(on, false)
        sw.onChange = change
        row.addView(sw)
        return row to sw
    }

    /** Purple track, white thumb, value text on the right. */
    fun slider(c: Context, label: String, min: Int, max: Int, cur: Int, fmt: (Int) -> String,
               onChange: (Int) -> Unit, onDone: ((Int) -> Unit)? = null): LinearLayout {
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        if (label.isNotEmpty()) box.addView(title(c, label))
        val pn = panel(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val value = TextView(c).apply {
            text = fmt(cur); textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.END
        }
        val bgD = GradientDrawable().apply { cornerRadius = c.dpf(14f); setColor(Color.parseColor("#DDDDDD")); setSize(0, c.dp(26)) }
        val fgD = ClipDrawable(
            GradientDrawable().apply { cornerRadius = c.dpf(14f); setColor(Theme.PURPLE); setSize(0, c.dp(26)) },
            Gravity.START, ClipDrawable.HORIZONTAL)
        val layer = LayerDrawable(arrayOf(bgD, fgD)).apply {
            setId(0, android.R.id.background); setId(1, android.R.id.progress)
        }
        val thumb = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(c.dp(2), Theme.PURPLE)
            setSize(c.dp(30), c.dp(30))
        }
        val sb = SeekBar(c).apply {
            this.max = max - min; progress = cur - min
            progressDrawable = layer; this.thumb = thumb; splitTrack = false
            setPadding(c.dp(14), 0, c.dp(14), 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    value.text = fmt(p + min)
                    if (user) onChange(p + min)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { onDone?.invoke((s?.progress ?: 0) + min) }
            })
        }
        pn.addView(sb, LinearLayout.LayoutParams(0, c.dp(36), 1f))
        pn.addView(value, LinearLayout.LayoutParams(c.dp(56), -2))
        box.addView(pn)
        return box
    }
}
