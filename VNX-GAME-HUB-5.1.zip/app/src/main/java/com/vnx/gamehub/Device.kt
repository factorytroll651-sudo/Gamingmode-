package com.vnx.gamehub

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class Dev(
    val brand: String, val model: String, val android: String, val sdk: Int,
    val ramMb: Long, val soc: String, val widthPx: Int, val heightPx: Int,
    val dpi: Int, val swDp: Int, val inches: Double, val hz: Float, val tier: Int
) {
    val tierName: String get() = when (tier) { 0 -> "ENTRY"; 1 -> "MID"; 2 -> "UPPER-MID"; else -> "FLAGSHIP" }
}

object Device {

    /** Free Fire sliders now go up to 200, so the 0-100 estimate is doubled. */
    const val SENSI_MAX = 200

    @Volatile var motion = 3
    @Volatile var avoidOvershoot = false
    @Volatile var controlSpeed = false
    @Volatile var optimized = true

    /** Reads the BUTTON page tuning switches so the generator can use them. */
    fun loadTune(c: Context) {
        motion = Prefs.getInt(c, "motion_level", 3).coerceIn(1, 5)
        avoidOvershoot = Prefs.getBool(c, "avoid_over", false)
        controlSpeed = Prefs.getBool(c, "ctrl_speed", false)
        optimized = Prefs.getBool(c, "opt_sensi", true)
    }
    private const val SENSI_SCALE = 2.0

    fun read(c: Context): Dev {
        val dm = c.resources.displayMetrics
        val w = max(dm.widthPixels, dm.heightPixels)
        val h = min(dm.widthPixels, dm.heightPixels)
        val xd = if (dm.xdpi > 0) dm.xdpi else dm.densityDpi.toFloat()
        val yd = if (dm.ydpi > 0) dm.ydpi else dm.densityDpi.toFloat()
        val inches = sqrt((w / xd).toDouble() * (w / xd) + (h / yd).toDouble() * (h / yd))
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        val hz = wm.defaultDisplay.refreshRate
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val ram = mi.totalMem / 1048576
        val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != "unknown")
            "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE
        val tier = when {
            ram >= 11000 -> 3
            ram >= 7000 -> 2
            ram >= 5000 -> 1
            else -> 0
        }
        val sw = (min(dm.widthPixels, dm.heightPixels) / dm.density).toInt()
        return Dev(Build.MANUFACTURER.replaceFirstChar { it.uppercase() }, Build.MODEL, Build.VERSION.RELEASE,
            Build.VERSION.SDK_INT, ram, soc, w, h, dm.densityDpi, sw, inches, hz, tier)
    }

    fun details(d: Dev): String =
        "Device   : ${d.brand} ${d.model}\n" +
            "Android  : ${d.android} (API ${d.sdk})\n" +
            "Chipset  : ${d.soc}\n" +
            "RAM      : ${d.ramMb} MB  (${d.tierName})\n" +
            "Screen   : ${"%.1f".format(d.inches)} in  ${d.widthPx}x${d.heightPx}\n" +
            "Density  : ${d.dpi} dpi  (smallest width ${d.swDp} dp)\n" +
            "Refresh  : ${d.hz.roundToInt()} Hz"

    /**
     * Starting-point values for Free Fire's sensitivity sliders.
     * style: 0 = balanced, 1 = fast flick, 2 = precise.
     * These are estimates from screen size, refresh rate and device tier. Fine-tune them
     * in the training ground.
     */
    fun sensi(d: Dev, style: Int): LinkedHashMap<String, Int> {
        var base = 88.0
        if (optimized) {
            base += (d.inches - 6.5) * 7.0
            base -= (d.hz - 60f) / 30f * 4.0
            base += when (d.tier) { 0 -> -3.0; 1 -> 0.0; 2 -> 2.0; else -> 3.0 }
        }
        base += when (style) { 1 -> 6.0; 2 -> -6.0; else -> 0.0 }
        base += (motion - 3) * 3.0
        if (controlSpeed) base -= 4.0
        val ov = if (avoidOvershoot) 0.92 else 1.0
        fun cl(v: Double) = (v * SENSI_SCALE).roundToInt().coerceIn(20, SENSI_MAX)
        val m = LinkedHashMap<String, Int>()
        m["General"] = cl(base)
        m["Red Dot"] = cl((base - 4) * ov)
        m["2x Scope"] = cl((base - 9) * ov)
        m["4x Scope"] = cl((base - 15) * ov)
        m["AWM Scope"] = cl((base - 30) * ov)
        m["Free Look"] = cl((base - 8) * ov)
        return m
    }

    fun sensiText(m: Map<String, Int>): String = m.entries.joinToString("\n") { "${it.key}=${it.value}" }

    fun dpiCalc(d: Dev, targetSwDp: Int): String {
        if (targetSwDp < 280 || targetSwDp > 600) return "Enter a smallest-width between 280 and 600 dp."
        val px = min(d.widthPx, d.heightPx)
        val newDpi = (px * 160.0 / targetSwDp).roundToInt()
        return "Now : ${d.dpi} dpi (sw ${d.swDp} dp)\nNew : $newDpi dpi (sw $targetSwDp dp)\n\n" +
            "Apply with ADB:\nadb shell wm density $newDpi\n\nReset anytime:\nadb shell wm density reset\n" +
            "(Lower dpi = smaller UI, more screen visible. Some phones glitch below sw 320.)"
    }

    fun hud(d: Dev): String {
        val claw = when {
            d.inches < 6.2 -> "3-finger claw"
            d.inches < 6.8 -> "3 or 4-finger claw"
            else -> "4-finger claw"
        }
        val fire = if (d.inches >= 6.7) "55-62%" else "60-70%"
        return "HUD GUIDE for ${d.brand} ${d.model} (${"%.1f".format(d.inches)} in)\n\n" +
            "Layout        : $claw\n" +
            "Fire button   : size $fire, opacity 70-80%\n" +
            "Scope / aim   : keep within thumb reach of the fire button\n" +
            "Jump / crouch : near the right thumb, small and spaced out\n" +
            "Extra fire    : add a left-side fire button to shoot while moving\n" +
            "Opacity       : 60-75% on every button, so the screen stays clear\n\n" +
            "Move the buttons in Free Fire > Settings > Controls > Customize HUD."
    }

    const val OPT_TIPS =
        "OPTIMIZATION TIPS\n\n" +
            "1. Use BOOST mode in Keox Ff before you start.\n" +
            "2. Close other apps; CLEAN RAM does this for you.\n" +
            "3. Free Fire: Settings > Graphics > Smooth; frame rate High or Max.\n" +
            "4. Keep 2 GB of free storage; clear Free Fire cache if it stutters.\n" +
            "5. Play at 20-80% battery, and avoid charging while playing (heat slows the chip).\n" +
            "6. Remove the thick case if the phone gets hot.\n" +
            "7. Wi-Fi 5 GHz or a good mobile signal; lower ping matters more than graphics.\n" +
            "8. Turn on Game Mode / Game Space in your phone settings too."

    const val TRAIN_TIPS =
        "HEADSHOT TRAINING (10 min a day)\n\n" +
            "1. Training ground: shoot a bot's head from 10, 20 and 30 metres.\n" +
            "2. Crosshair placement: keep it at head height before the enemy shows up.\n" +
            "3. Tap and burst fire, not full spray; reset your aim between bursts.\n" +
            "4. Aim at the neck, then lift slightly; the head is reached more easily.\n" +
            "5. Practise with ONE gun until it feels natural (for example UMP or MP40).\n" +
            "6. Lower your sensitivity if you keep overshooting; raise it if you can't turn.\n" +
            "7. Review a lost fight: did you peek too long or aim too late?"
}

/** Offline answers, used when no AI key is saved. Only gaming topics. */
object Coach {
    private val topics = listOf(
        listOf("ump") to "UMP tips: it is a close/mid-range SMG with low recoil. Keep the crosshair at head height, " +
            "fire in 3-4 bullet bursts, and strafe left-right while shooting. Add a compensator or foregrip if you can.",
        listOf("awm", "sniper") to "AWM tips: scope in only after you stop moving, lead moving targets a little, " +
            "and lower the AWM scope sensitivity. One body shot knocks, one head shot kills, so wait for the peek.",
        listOf("m1887", "m1014", "shotgun") to "Shotgun tips: stay within 10 metres, jump-peek around corners, " +
            "and fire the moment the enemy is in the crosshair. Switch to an SMG if they stay far away.",
        listOf("sensi", "sensitivity") to "Sensitivity: open the SENSI page in this app. It reads your phone and " +
            "gives starting values. Test in the training ground, and raise or lower General by 3-5 at a time.",
        listOf("headshot", "head shot", "aim") to "Headshot basics: crosshair at head height, burst fire, " +
            "short aim resets, and practise one gun in the training ground. See HEADSHOT TRAINING on the SENSI page.",
        listOf("lag", "ping", "fps") to "Lag fix: use BOOST mode, CLEAN RAM, 5 GHz Wi-Fi or strong 4G/5G, " +
            "close downloads, and set Free Fire graphics to Smooth with high FPS.",
        listOf("rank", "push", "conqueror", "heroic") to "Rank push: play with a squad, drop in the safe zone edge, " +
            "take fights with cover, and rotate early. Do not chase kills in the last two circles.",
        listOf("clutch", "1v4", "1v3") to "Clutch tips: use gloo walls to heal, keep distance, fight one enemy at a time, " +
            "and use grenades or a vehicle to split the squad."
    )
    private val gaming = listOf("free fire", "freefire", " ff", "ff ", "gun", "weapon", "headshot", "sensi", "sensitivity",
        "ump", "awm", "mp40", "m1887", "m1014", "scar", "ak", "squad", "rank", "booyah", "character", "pet",
        "map", "bermuda", "purgatory", "kalahari", "game", "gaming", "fps", "ping", "lag", "hud", "aim",
        "clutch", "headshot", "drop", "zone", "bot", "training", "pubg", "cod", "bgmi", "mobile")

    fun offline(q: String): String {
        val s = " " + q.lowercase() + " "
        for ((keys, ans) in topics) if (keys.any { s.contains(it) }) return "(offline tips)\n$ans"
        if (gaming.any { s.contains(it) })
            return "(offline tips)\nAdd your AI key in SETTINGS for a full answer. Meanwhile: practise in the " +
                "training ground, keep your crosshair at head height, and use burst fire."
        return "I only answer Free Fire and mobile-gaming questions. Ask me about guns, headshots, sensitivity, " +
            "ranks, characters, maps or lag."
    }
}
