package com.vnx.gamehub

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object Theme {
    val BG = Color.parseColor("#262626")
    val PURPLE = Color.parseColor("#B000F0")
    val PINK = Color.parseColor("#B000F0")
    val CYAN = Color.parseColor("#C84BFF")
    val GOLD = Color.parseColor("#FBBF24")
    val GREEN = Color.parseColor("#34D399")
    val RED = Color.parseColor("#F43F5E")
    val CARD_A = Color.parseColor("#F0141414")
    val CARD_B = Color.parseColor("#F01C1C1C")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Animated anime-style backdrop: aura glows, drifting speed lines and falling sakura petals. */
class AnimeBackgroundView(ctx: Context) : View(ctx) {
    private class Petal(var x: Float, var y: Float, val s: Float, val v: Float,
                        val sway: Float, var rot: Float, val vr: Float, val a: Int)

    private val rnd = Random(7)
    private val petals = ArrayList<Petal>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private var phase = 0f
    private var bg: LinearGradient? = null

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 12000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            step()
            invalidate()
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(Color.parseColor("#0B0714"), Color.parseColor("#1A0B2E"), Color.parseColor("#0A1230")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        petals.clear()
        repeat(26) {
            petals.add(Petal(rnd.nextFloat() * w, rnd.nextFloat() * h,
                context.dpf(4f + rnd.nextFloat() * 6f), context.dpf(0.6f + rnd.nextFloat() * 1.4f),
                rnd.nextFloat() * 6.28f, rnd.nextFloat() * 360f, -1.5f + rnd.nextFloat() * 3f,
                80 + rnd.nextInt(120)))
        }
    }

    private fun step() {
        for (q in petals) {
            q.y += q.v
            q.x += sin(phase * 6.28f * 2 + q.sway) * 0.7f
            q.rot += q.vr
            if (q.y > height + 30) { q.y = -30f; q.x = rnd.nextFloat() * width }
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = bg; p.style = Paint.Style.FILL
        c.drawRect(0f, 0f, w, h, p)

        val pulse = 0.85f + 0.15f * sin(phase * 6.28f)
        glow(c, w * 0.85f, h * 0.12f, w * 0.7f * pulse, Theme.PURPLE, 90)
        glow(c, w * 0.1f, h * 0.55f, w * 0.65f * (2f - pulse), Theme.PINK, 55)
        glow(c, w * 0.8f, h * 0.9f, w * 0.6f * pulse, Theme.CYAN, 50)

        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = context.dpf(1f)
        for (i in 0 until 14) {
            val y = ((i * 0.077f + phase * 0.35f) % 1f) * h
            p.color = Color.argb(if (i % 3 == 0) 40 else 22, 160, 130, 255)
            c.drawLine(-20f, y + 60f, w + 20f, y - 90f, p)
        }

        p.style = Paint.Style.FILL
        for (q in petals) {
            c.save(); c.translate(q.x, q.y); c.rotate(q.rot)
            p.color = Color.argb(q.a, 255, 183, 213)
            oval.set(-q.s, -q.s * 0.55f, q.s, q.s * 0.55f)
            c.drawOval(oval, p)
            p.color = Color.argb(q.a / 2, 255, 255, 255)
            oval.set(-q.s * 0.4f, -q.s * 0.2f, q.s * 0.4f, q.s * 0.2f)
            c.drawOval(oval, p)
            c.restore()
        }
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int, alpha: Int) {
        p.shader = RadialGradient(x, y, r, Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)),
            Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
        p.shader = null
    }
}

/** Title text with a moving light sweep. */
class ShimmerText(ctx: Context) : TextView(ctx) {
    private val m = Matrix()
    private var sh: LinearGradient? = null
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { v ->
            val s = sh ?: return@addUpdateListener
            m.setTranslate((v.animatedValue as Float) * width * 2.2f - width * 0.6f, 0f)
            s.setLocalMatrix(m)
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sh = LinearGradient(0f, 0f, w * 0.6f, 0f,
            intArrayOf(Theme.PURPLE, Theme.PINK, Color.WHITE, Theme.CYAN, Theme.PURPLE),
            floatArrayOf(0f, 0.3f, 0.5f, 0.7f, 1f), Shader.TileMode.CLAMP)
        paint.shader = sh
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}

fun cardBg(c: Context, accent: Int, on: Boolean): GradientDrawable {
    val first = if (on) Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent)) else Theme.CARD_A
    return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(first, Theme.CARD_B)).apply {
        cornerRadius = c.dpf(18f)
        if (on) setStroke(c.dp(2), accent)
        else setStroke(c.dp(1), Color.argb(170, Color.red(accent), Color.green(accent), Color.blue(accent)))
    }
}

class NeonCard(val root: LinearLayout, val title: TextView, val sub: TextView, val accent: Int) {
    fun setOn(on: Boolean, onText: String, offText: String) {
        sub.text = if (on) onText else offText
        sub.setTextColor(if (on) accent else Color.parseColor("#A99CC8"))
        root.background = cardBg(root.context, accent, on)
    }
}

fun neonCard(c: Context, glyph: String, title: String, sub: String, accent: Int): NeonCard {
    val root = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(c.dp(14), c.dp(14), c.dp(14), c.dp(14))
        background = cardBg(c, accent, false)
        isClickable = true
        elevation = c.dpf(6f)
    }
    val g = TextView(c).apply { text = glyph; textSize = 22f; setTextColor(accent) }
    val t = TextView(c).apply {
        text = title; textSize = 14f; setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); letterSpacing = 0.05f
        setPadding(0, c.dp(6), 0, 0)
    }
    val s = TextView(c).apply { text = sub; textSize = 11f; setTextColor(Color.parseColor("#A99CC8")) }
    root.addView(g); root.addView(t); root.addView(s)
    root.setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator(2.5f)).start()
        }
        false
    }
    return NeonCard(root, t, s, accent)
}

fun enter(v: View, index: Int) {
    v.alpha = 0f
    v.translationY = v.context.dpf(36f)
    v.animate().alpha(1f).translationY(0f).setStartDelay(80L + index * 45L).setDuration(520)
        .setInterpolator(OvershootInterpolator(1.1f)).start()
}

fun sectionLabel(c: Context, text: String): TextView = TextView(c).apply {
    this.text = text; textSize = 11f; letterSpacing = 0.25f
    setTextColor(Theme.CYAN); typeface = Typeface.DEFAULT_BOLD
    setPadding(c.dp(4), c.dp(20), 0, c.dp(8)); gravity = Gravity.START
}

/** Circle button. Style, border, colour and contrast come from the BUTTON page. */
class CircleView(ctx: Context, usePrefs: Boolean = true) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var style = 0
    var borderDp = 3
    var contrast = true
    var color = Color.parseColor("#B000F0")
    var locked = false
        set(v) { field = v; invalidate() }

    init { if (usePrefs) load() }

    fun load() {
        style = Prefs.getInt(context, "circle_style", 0)
        borderDp = Prefs.getInt(context, "circle_border", 3)
        contrast = Prefs.getBool(context, "circle_contrast", true)
        color = Prefs.getInt(context, "circle_color", Color.parseColor("#B000F0"))
        invalidate()
    }

    fun pulse() {
        animate().scaleX(1.15f).scaleY(1.15f).setDuration(90).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(160).start()
        }.start()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy)
        val bw = context.dpf(borderDp.toFloat()).coerceAtMost(r * 0.35f).coerceAtLeast(2f)
        val ring = if (locked) Color.parseColor("#FBBF24") else color
        p.pathEffect = null
        if (contrast) {
            p.style = Paint.Style.FILL; p.color = Color.argb(150, 20, 8, 30)
            c.drawCircle(cx, cy, r * 0.95f, p)
        }
        val rr = r * 0.95f - bw / 2f
        when (style) {
            2 -> { // clean
                p.style = Paint.Style.FILL
                p.color = Color.argb(110, Color.red(ring), Color.green(ring), Color.blue(ring))
                c.drawCircle(cx, cy, r * 0.9f, p)
            }
            1 -> { // outlined (dashed)
                p.style = Paint.Style.STROKE; p.strokeWidth = bw; p.color = ring
                p.pathEffect = android.graphics.DashPathEffect(floatArrayOf(bw * 2.6f, bw * 2f), 0f)
                c.drawCircle(cx, cy, rr, p)
                p.pathEffect = null
            }
            else -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = bw; p.color = ring
                c.drawCircle(cx, cy, rr, p)
            }
        }
        if (style == 3) { // crossed
            p.style = Paint.Style.STROKE; p.strokeWidth = bw * 0.6f; p.color = ring
            c.drawLine(cx - rr, cy, cx + rr, cy, p)
            c.drawLine(cx, cy - rr, cx, cy + rr, p)
        } else {
            p.style = Paint.Style.FILL; p.color = ring
            c.drawCircle(cx, cy, maxOf(bw * 0.7f, r * 0.06f), p)
        }
    }
}

/** Small padlock bubble that stays touchable so the circle can be locked or unlocked. */
class LockChip(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    var locked = false
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy)
        p.style = Paint.Style.FILL
        p.color = if (locked) Theme.GOLD else Color.parseColor("#2A1650")
        c.drawCircle(cx, cy, r * 0.95f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.12f
        p.color = Color.WHITE; c.drawCircle(cx, cy, r * 0.95f, p)

        p.style = Paint.Style.FILL
        p.color = if (locked) Color.parseColor("#1B1236") else Color.WHITE
        box.set(cx - r * 0.38f, cy - r * 0.05f, cx + r * 0.38f, cy + r * 0.48f)
        c.drawRoundRect(box, r * 0.1f, r * 0.1f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.14f
        val lift = if (locked) 0f else r * 0.2f
        box.set(cx - r * 0.24f, cy - r * 0.5f - lift, cx + r * 0.24f, cy + r * 0.1f - lift)
        c.drawArc(box, 180f, 180f, false, p)
        if (locked) c.drawLine(cx - r * 0.24f, cy - r * 0.2f, cx - r * 0.24f, cy, p)
    }
}


/** Slide switch: tap it or drag the knob across to turn something on or off. */
class SlideToggle(ctx: Context, private val accent: Int = Theme.GREEN) : View(ctx) {
    var onChange: ((Boolean) -> Unit)? = null
    private var checked = false
    private var pos = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private var downX = 0f
    private var startPos = 0f
    private var dragging = false
    private var anim: ValueAnimator? = null

    fun setChecked(v: Boolean, animate: Boolean = true) { checked = v; animateTo(if (v) 1f else 0f, animate) }
    fun isOn() = checked

    private fun animateTo(t: Float, animate: Boolean) {
        anim?.cancel()
        if (!animate) { pos = t; invalidate(); return }
        anim = ValueAnimator.ofFloat(pos, t).apply {
            duration = 180
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(56), context.dp(30))

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val off = Color.parseColor("#3A2A5C")
        p.style = Paint.Style.FILL
        p.color = Color.argb(255,
            (Color.red(off) + (Color.red(accent) - Color.red(off)) * pos).toInt(),
            (Color.green(off) + (Color.green(accent) - Color.green(off)) * pos).toInt(),
            (Color.blue(off) + (Color.blue(accent) - Color.blue(off)) * pos).toInt())
        box.set(0f, 0f, w, h)
        c.drawRoundRect(box, h / 2, h / 2, p)
        p.color = Color.WHITE
        c.drawCircle(h / 2 + pos * (w - h), h / 2, h / 2 - context.dpf(3f), p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; startPos = pos; dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                if (abs(dx) > context.dp(4)) dragging = true
                if (dragging) { pos = (startPos + dx / (width - height)).coerceIn(0f, 1f); invalidate() }
            }
            MotionEvent.ACTION_UP -> {
                val want = if (dragging) pos > 0.5f else !checked
                if (want != checked) {
                    checked = want; animateTo(if (want) 1f else 0f, true); onChange?.invoke(want)
                } else animateTo(if (checked) 1f else 0f, true)
            }
            MotionEvent.ACTION_CANCEL -> animateTo(if (checked) 1f else 0f, true)
        }
        return true
    }
}

/** Thin quiet tab on the screen edge. Swipe it inward (or tap it) to open the panel. */
class EdgeHandle(ctx: Context, private val right: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = Color.argb(150, 176, 0, 240)
        box.set(if (right) 0f else -w, 0f, if (right) w + w else w, h)
        c.drawRoundRect(box, w, w, p)
        p.color = Color.argb(190, 255, 255, 255)
        val x = if (right) w * 0.38f else w * 0.62f
        for (i in -1..1) c.drawCircle(x, h / 2 + i * h * 0.12f, w * 0.09f, p)
    }
}

// ---------- v5 premium widgets ----------

/** Rounded icon tile with a label under it. Tap = run, highlighted = ON. */
class Tile(val root: LinearLayout, val icon: TextView, val label: TextView, private val accent: Int) {
    fun setOn(on: Boolean) {
        val c = root.context
        icon.setTextColor(Color.WHITE)
        icon.background = GradientDrawable().apply {
            cornerRadius = c.dpf(18f)
            setColor(if (on) accent else Color.parseColor("#3A3A46"))
        }
        label.setTextColor(if (on) accent else Color.parseColor("#E8E8F0"))
    }
}

fun tile(c: Context, glyph: String, text: String, accent: Int): Tile {
    val root = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(c.dp(4), c.dp(8), c.dp(4), c.dp(8))
        isClickable = true
    }
    val icon = TextView(c).apply { this.text = glyph; textSize = 22f; gravity = Gravity.CENTER }
    root.addView(icon, LinearLayout.LayoutParams(c.dp(58), c.dp(58)))
    val lab = TextView(c).apply {
        this.text = text; textSize = 11f; gravity = Gravity.CENTER; maxLines = 2
        setPadding(0, c.dp(6), 0, 0)
    }
    root.addView(lab, LinearLayout.LayoutParams(-2, -2))
    root.setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(150).setInterpolator(OvershootInterpolator(2.5f)).start()
        }
        false
    }
    val t = Tile(root, icon, lab, accent)
    t.setOn(false)
    return t
}

/** Pill selector, like BATTERY SAVER | BALANCED | BOOST. */
class Segmented(ctx: Context, items: List<String>, private val accent: Int) : LinearLayout(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    private val tvs = ArrayList<TextView>()
    private var sel = 0

    init {
        orientation = HORIZONTAL
        background = GradientDrawable().apply { cornerRadius = ctx.dpf(14f); setColor(Color.parseColor("#2A2A34")) }
        setPadding(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
        items.forEachIndexed { i, t ->
            val tv = TextView(ctx).apply {
                text = t; gravity = Gravity.CENTER; textSize = 11f; typeface = Typeface.DEFAULT_BOLD
                setPadding(ctx.dp(4), ctx.dp(10), ctx.dp(4), ctx.dp(10))
                setOnClickListener { select(i, true) }
            }
            tvs.add(tv)
            addView(tv, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        paintSel()
    }

    fun select(i: Int, fire: Boolean) {
        sel = i; paintSel()
        if (fire) onSelect?.invoke(i)
    }

    private fun paintSel() {
        tvs.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == sel) Color.WHITE else Color.parseColor("#9A9AA8"))
            tv.background = if (i == sel) GradientDrawable().apply {
                cornerRadius = context.dpf(11f); setColor(accent)
            } else null
        }
    }
}

/** Round gauge with a percent in the middle. */
class GaugeView(ctx: Context, private val accent: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private var shown = 0f
    private var title = ""

    fun set(v: Int, t: String) {
        title = t
        ValueAnimator.ofFloat(shown, v.coerceIn(0, 100).toFloat()).apply {
            duration = 600
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(96), context.dp(96))

    override fun onDraw(c: Canvas) {
        val s = width.toFloat(); val st = s * 0.09f
        box.set(st, st, s - st, s - st)
        p.style = Paint.Style.STROKE; p.strokeWidth = st; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#33FFFFFF"); c.drawArc(box, 135f, 270f, false, p)
        p.color = accent; c.drawArc(box, 135f, 270f * shown / 100f, false, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = Color.WHITE; p.textSize = s * 0.25f; p.typeface = Typeface.DEFAULT_BOLD
        c.drawText("${shown.toInt()}%", s / 2, s / 2 + s * 0.05f, p)
        p.color = Color.parseColor("#A0A0B0"); p.textSize = s * 0.12f; p.typeface = Typeface.DEFAULT
        c.drawText(title, s / 2, s / 2 + s * 0.25f, p)
    }
}
