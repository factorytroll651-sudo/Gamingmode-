# VNX GAME HUB 4.0

## Repo ke sabse upar (root) ye hona chahiye
- app/                       (folder)
- .github/workflows/build.yml
- settings.gradle.kts
- build.gradle.kts
- gradle.properties
- .gitignore

app/ ke andar: build.gradle.kts, src/main/AndroidManifest.xml,
src/main/java/com/vnx/gamehub/{MainActivity,Ui,Tools,FloatingService}.kt,
src/main/res/values/{strings,styles}.xml, src/main/res/drawable/ic_launcher.xml

## Build
Actions tab > Build APK > Run workflow. Hara tick aane par run kholo,
neeche Artifacts se VNX-GAME-HUB-apk download karo.

## .github upload na ho to
GitHub par Add file > Create new file, naam: .github/workflows/build.yml
aur WORKFLOW_build.yml.txt ka content paste karo.

## Pehli baar app mein
OVERLAY, SETTINGS, DND ACCESS permission do. Boost/Touches ke liye ek baar ADB:
adb shell pm grant com.vnx.gamehub android.permission.WRITE_SECURE_SETTINGS
