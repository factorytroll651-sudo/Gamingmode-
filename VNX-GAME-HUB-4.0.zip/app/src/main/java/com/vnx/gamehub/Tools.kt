package com.vnx.gamehub

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vnx", Context.MODE_PRIVATE)

    fun getInt(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun getBool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun getLong(c: Context, k: String, d: Long) = sp(c).getLong(k, d)
    fun putLong(c: Context, k: String, v: Long) = sp(c).edit().putLong(k, v).apply()
    fun getStr(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    const val DEFAULT_SENSI =
        "General=100\nRed Dot=95\n2x Scope=90\n4x Scope=85\nAWM Scope=60\nFree Look=80"
}

/** Every tool returns a short report string that the UI prints in its console. */
object Tools {
    private const val ADB_HINT =
        "needs one-time ADB: adb shell pm grant com.vnx.gamehub android.permission.WRITE_SECURE_SETTINGS"

    fun gameOn(c: Context): String {
        val sb = StringBuilder("GAME MODE ON\n")
        val cr = c.contentResolver
        if (Settings.System.canWrite(c)) {
            try {
                Prefs.putInt(c, "prev_bmode", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 1))
                Prefs.putInt(c, "prev_rot", Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1))
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 255)
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
                sb.append("[OK] Brightness MAX | Rotation LOCKED\n")
            } catch (e: Exception) {
                sb.append("[X] Display: ").append(e.message).append('\n')
            }
        } else sb.append("[X] Display: grant 'Modify system settings' first\n")

        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            Prefs.putInt(c, "prev_filter", nm.currentInterruptionFilter)
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            sb.append("[OK] Do Not Disturb ON\n")
        } else sb.append("[X] DND: grant Do Not Disturb access first\n")
        Prefs.putBool(c, "game_on", true)
        return sb.toString().trim()
    }

    fun gameOff(c: Context): String {
        val sb = StringBuilder("GAME MODE OFF\n")
        val cr = c.contentResolver
        if (Settings.System.canWrite(c)) {
            try {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Prefs.getInt(c, "prev_bmode", 1))
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, Prefs.getInt(c, "prev_rot", 1))
                sb.append("[OK] Auto brightness | Rotation restored\n")
            } catch (e: Exception) {
                sb.append("[X] Display: ").append(e.message).append('\n')
            }
        } else sb.append("[X] Display: grant 'Modify system settings' first\n")

        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(
                Prefs.getInt(c, "prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL)
            )
            sb.append("[OK] Do Not Disturb restored\n")
        } else sb.append("[X] DND: grant Do Not Disturb access first\n")
        Prefs.putBool(c, "game_on", false)
        return sb.toString().trim()
    }

    fun gameToggle(c: Context): String =
        if (Prefs.getBool(c, "game_on", false)) gameOff(c) else gameOn(c)

    fun boost(c: Context, on: Boolean): String {
        val v = if (on) 0.5f else 1.0f
        val cr = c.contentResolver
        return try {
            Settings.Global.putFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, v)
            Settings.Global.putFloat(cr, Settings.Global.TRANSITION_ANIMATION_SCALE, v)
            Settings.Global.putFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, v)
            if (on) "PERFORMANCE BOOST\n[OK] Animation scale 0.5x"
            else "PERFORMANCE RESET\n[OK] Animation scale 1.0x"
        } catch (e: SecurityException) {
            "[X] Animation scale $ADB_HINT"
        }
    }

    fun touches(c: Context, on: Boolean): String = try {
        Settings.System.putInt(c.contentResolver, "show_touches", if (on) 1 else 0)
        if (on) "[OK] Touch points VISIBLE" else "[OK] Touch points HIDDEN"
    } catch (e: Exception) {
        "[X] Show touches $ADB_HINT"
    }

    fun tcpPing(host: String, port: Int): String {
        val t0 = System.nanoTime()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), 2000) }
            "${(System.nanoTime() - t0) / 1_000_000} ms"
        } catch (e: Exception) {
            "FAIL"
        }
    }

    fun system(c: Context): String {
        val am = c.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        return "SYSTEM CHECK\n" +
            "Device : ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "RAM    : ${mi.availMem / 1048576} / ${mi.totalMem / 1048576} MB free\n" +
            "Battery: ${if (lvl >= 0) lvl * 100 / sc else 0}%  ${temp}C\n" +
            "Ping   : ${tcpPing("8.8.8.8", 53)}"
    }

    fun network(): String =
        "NETWORK DIAG\n" +
            "8.8.8.8    : ${tcpPing("8.8.8.8", 53)}\n" +
            "1.1.1.1    : ${tcpPing("1.1.1.1", 53)}\n" +
            "google.com : ${tcpPing("google.com", 443)}"

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

    fun sessionStart(c: Context): String {
        Prefs.putLong(c, "sess_start", System.currentTimeMillis())
        appendLog(c, "${now()} START")
        return "SESSION STARTED"
    }

    fun sessionStats(c: Context): String {
        val s = Prefs.getLong(c, "sess_start", 0L)
        val total = Prefs.getStr(c, "sess_log", "").lines().count { it.contains("START") }
        val run = if (s > 0) "${(System.currentTimeMillis() - s) / 60000} MIN" else "NO ACTIVE SESSION"
        return "SESSION STATS\nRunning : $run\nTotal   : $total sessions"
    }

    fun sessionEnd(c: Context): String {
        val s = Prefs.getLong(c, "sess_start", 0L)
        if (s <= 0) return "NO ACTIVE SESSION"
        val m = (System.currentTimeMillis() - s) / 60000
        appendLog(c, "${now()} END $m MIN")
        Prefs.putLong(c, "sess_start", 0L)
        return "SESSION ENDED: $m MIN"
    }

    private fun appendLog(c: Context, line: String) {
        val all = (Prefs.getStr(c, "sess_log", "").lines().filter { it.isNotBlank() } + line).takeLast(60)
        Prefs.putStr(c, "sess_log", all.joinToString("\n"))
    }

    fun sensi(c: Context): String {
        val rows = Prefs.getStr(c, "sensi", Prefs.DEFAULT_SENSI).lines().filter { it.contains("=") }
        return "SENSI PRESETS (your in-game values)\n" + rows.joinToString("\n") {
            val p = it.split("=", limit = 2)
            p[0].trim().padEnd(10) + " " + p[1].trim()
        }
    }
}
