package com.vnx.gamehub

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object Theme {
    val BG = Color.parseColor("#0B0714")
    val PURPLE = Color.parseColor("#7C3AED")
    val PINK = Color.parseColor("#FF4D8D")
    val CYAN = Color.parseColor("#22D3EE")
    val GOLD = Color.parseColor("#FBBF24")
    val GREEN = Color.parseColor("#34D399")
    val RED = Color.parseColor("#F43F5E")
    val CARD_A = Color.parseColor("#E61B1236")
    val CARD_B = Color.parseColor("#E62A1650")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Animated anime-style backdrop: aura glows, drifting speed lines and falling sakura petals. */
class AnimeBackgroundView(ctx: Context) : View(ctx) {
    private class Petal(var x: Float, var y: Float, val s: Float, val v: Float,
                        val sway: Float, var rot: Float, val vr: Float, val a: Int)

    private val rnd = Random(7)
    private val petals = ArrayList<Petal>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private var phase = 0f
    private var bg: LinearGradient? = null

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 12000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            step()
            invalidate()
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(Color.parseColor("#0B0714"), Color.parseColor("#1A0B2E"), Color.parseColor("#0A1230")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        petals.clear()
        repeat(26) {
            petals.add(Petal(rnd.nextFloat() * w, rnd.nextFloat() * h,
                context.dpf(4f + rnd.nextFloat() * 6f), context.dpf(0.6f + rnd.nextFloat() * 1.4f),
                rnd.nextFloat() * 6.28f, rnd.nextFloat() * 360f, -1.5f + rnd.nextFloat() * 3f,
                80 + rnd.nextInt(120)))
        }
    }

    private fun step() {
        for (q in petals) {
            q.y += q.v
            q.x += sin(phase * 6.28f * 2 + q.sway) * 0.7f
            q.rot += q.vr
            if (q.y > height + 30) { q.y = -30f; q.x = rnd.nextFloat() * width }
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = bg; p.style = Paint.Style.FILL
        c.drawRect(0f, 0f, w, h, p)

        val pulse = 0.85f + 0.15f * sin(phase * 6.28f)
        glow(c, w * 0.85f, h * 0.12f, w * 0.7f * pulse, Theme.PURPLE, 90)
        glow(c, w * 0.1f, h * 0.55f, w * 0.65f * (2f - pulse), Theme.PINK, 55)
        glow(c, w * 0.8f, h * 0.9f, w * 0.6f * pulse, Theme.CYAN, 50)

        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = context.dpf(1f)
        for (i in 0 until 14) {
            val y = ((i * 0.077f + phase * 0.35f) % 1f) * h
            p.color = Color.argb(if (i % 3 == 0) 40 else 22, 160, 130, 255)
            c.drawLine(-20f, y + 60f, w + 20f, y - 90f, p)
        }

        p.style = Paint.Style.FILL
        for (q in petals) {
            c.save(); c.translate(q.x, q.y); c.rotate(q.rot)
            p.color = Color.argb(q.a, 255, 183, 213)
            oval.set(-q.s, -q.s * 0.55f, q.s, q.s * 0.55f)
            c.drawOval(oval, p)
            p.color = Color.argb(q.a / 2, 255, 255, 255)
            oval.set(-q.s * 0.4f, -q.s * 0.2f, q.s * 0.4f, q.s * 0.2f)
            c.drawOval(oval, p)
            c.restore()
        }
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int, alpha: Int) {
        p.shader = RadialGradient(x, y, r, Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)),
            Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
        p.shader = null
    }
}

/** Title text with a moving light sweep. */
class ShimmerText(ctx: Context) : TextView(ctx) {
    private val m = Matrix()
    private var sh: LinearGradient? = null
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { v ->
            val s = sh ?: return@addUpdateListener
            m.setTranslate((v.animatedValue as Float) * width * 2.2f - width * 0.6f, 0f)
            s.setLocalMatrix(m)
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sh = LinearGradient(0f, 0f, w * 0.6f, 0f,
            intArrayOf(Theme.PURPLE, Theme.PINK, Color.WHITE, Theme.CYAN, Theme.PURPLE),
            floatArrayOf(0f, 0.3f, 0.5f, 0.7f, 1f), Shader.TileMode.CLAMP)
        paint.shader = sh
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}

class NeonCard(val root: LinearLayout, val title: TextView, val sub: TextView)

fun neonCard(c: Context, glyph: String, title: String, sub: String, accent: Int): NeonCard {
    val root = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(c.dp(14), c.dp(14), c.dp(14), c.dp(14))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Theme.CARD_A, Theme.CARD_B)).apply {
            cornerRadius = c.dpf(18f)
            setStroke(c.dp(1), Color.argb(170, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        isClickable = true
        elevation = c.dpf(6f)
    }
    val g = TextView(c).apply { text = glyph; textSize = 22f; setTextColor(accent) }
    val t = TextView(c).apply {
        text = title; textSize = 14f; setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); letterSpacing = 0.05f
        setPadding(0, c.dp(6), 0, 0)
    }
    val s = TextView(c).apply { text = sub; textSize = 11f; setTextColor(Color.parseColor("#A99CC8")) }
    root.addView(g); root.addView(t); root.addView(s)
    root.setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator(2.5f)).start()
        }
        false
    }
    return NeonCard(root, t, s)
}

fun enter(v: View, index: Int) {
    v.alpha = 0f
    v.translationY = v.context.dpf(36f)
    v.animate().alpha(1f).translationY(0f).setStartDelay(80L + index * 45L).setDuration(520)
        .setInterpolator(OvershootInterpolator(1.1f)).start()
}

fun sectionLabel(c: Context, text: String): TextView = TextView(c).apply {
    this.text = text; textSize = 11f; letterSpacing = 0.25f
    setTextColor(Theme.CYAN); typeface = Typeface.DEFAULT_BOLD
    setPadding(c.dp(4), c.dp(20), 0, c.dp(8)); gravity = Gravity.START
}

/** Rotating-aura button that sits on the game screen. */
class CircleView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var rot = 0f
    var locked = false
        set(v) { field = v; invalidate() }

    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { rot = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    fun pulse() {
        animate().scaleX(1.25f).scaleY(1.25f).setDuration(110).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r, Color.argb(160, 20, 8, 40), Color.argb(230, 10, 4, 24), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 0.86f, p)
        p.shader = null

        val ring = if (locked) Theme.GOLD else Theme.PINK
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.12f
        c.save(); c.rotate(rot, cx, cy)
        p.shader = android.graphics.SweepGradient(cx, cy,
            intArrayOf(ring, Theme.PURPLE, Theme.CYAN, Color.TRANSPARENT, ring), null)
        val box = RectF(cx - r * 0.82f, cy - r * 0.82f, cx + r * 0.82f, cy + r * 0.82f)
        c.drawArc(box, 0f, 360f, false, p)
        c.restore(); p.shader = null

        p.style = Paint.Style.FILL; p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER; p.textSize = r * 0.8f
        p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        c.drawText("V", cx, cy + r * 0.28f, p)
        for (i in 0 until 3) {
            val a = Math.toRadians((rot * 1.6f + i * 120f).toDouble())
            p.color = Color.argb(220, 255, 255, 255)
            c.drawCircle(cx + (cos(a) * r * 0.82f).toFloat(), cy + (sin(a) * r * 0.82f).toFloat(), r * 0.05f, p)
        }
    }
}

/** Small padlock bubble that stays touchable so the circle can be locked or unlocked. */
class LockChip(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    var locked = false
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy)
        p.style = Paint.Style.FILL
        p.color = if (locked) Theme.GOLD else Color.parseColor("#2A1650")
        c.drawCircle(cx, cy, r * 0.95f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.12f
        p.color = Color.WHITE; c.drawCircle(cx, cy, r * 0.95f, p)

        p.style = Paint.Style.FILL
        p.color = if (locked) Color.parseColor("#1B1236") else Color.WHITE
        box.set(cx - r * 0.38f, cy - r * 0.05f, cx + r * 0.38f, cy + r * 0.48f)
        c.drawRoundRect(box, r * 0.1f, r * 0.1f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.14f
        val lift = if (locked) 0f else r * 0.2f
        box.set(cx - r * 0.24f, cy - r * 0.5f - lift, cx + r * 0.24f, cy + r * 0.1f - lift)
        c.drawArc(box, 180f, 180f, false, p)
        if (locked) c.drawLine(cx - r * 0.24f, cy - r * 0.2f, cx - r * 0.24f, cy, p)
    }
}
