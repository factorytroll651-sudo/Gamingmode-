package com.vnx.gamehub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.abs

/**
 * Floating circle. Unlocked: drag it anywhere, tap = Game Mode toggle.
 * Locked: the circle stops moving and becomes click-through, so touches go to the
 * app underneath (for example the game's fire button). The padlock bubble stays
 * touchable so you can unlock again.
 */
class FloatingService : Service() {

    companion object {
        const val ACT_START = "com.vnx.gamehub.START"
        const val ACT_STOP = "com.vnx.gamehub.STOP"
        const val ACT_UPDATE = "com.vnx.gamehub.UPDATE"
        const val ACT_TOGGLE_LOCK = "com.vnx.gamehub.TOGGLE_LOCK"
        private const val CH = "vnx_circle"
        private const val NID = 7
    }

    private lateinit var wm: WindowManager
    private var circle: CircleView? = null
    private var chip: LockChip? = null
    private var cp: WindowManager.LayoutParams? = null
    private var lp: WindowManager.LayoutParams? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        when (intent?.action ?: ACT_START) {
            ACT_STOP -> { shutdown(); return START_NOT_STICKY }
            ACT_TOGGLE_LOCK -> {
                Prefs.putBool(this, "locked", !Prefs.getBool(this, "locked", false))
                buzz(); applyPrefs(); notifyFg()
            }
            ACT_UPDATE -> { applyPrefs(); notifyFg() }
            else -> {
                if (!Settings.canDrawOverlays(this)) { shutdown(); return START_NOT_STICKY }
                notifyFg(); addViews(); Prefs.putBool(this, "circle_on", true)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() { removeViews(); super.onDestroy() }

    private fun shutdown() {
        Prefs.putBool(this, "circle_on", false)
        removeViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun size() = Prefs.getInt(this, "size_dp", 64)
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun baseFlags(locked: Boolean): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (locked) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private fun addViews() {
        if (circle != null) { applyPrefs(); return }
        val px = dp(size())
        val locked = Prefs.getBool(this, "locked", false)
        val c = CircleView(this)
        val c2 = LockChip(this)
        val p1 = WindowManager.LayoutParams(px, px, overlayType(), baseFlags(locked), PixelFormat.TRANSLUCENT)
        p1.gravity = Gravity.TOP or Gravity.START
        p1.x = Prefs.getInt(this, "cx", dp(40)); p1.y = Prefs.getInt(this, "cy", dp(300))
        val chipPx = dp(34)
        val p2 = WindowManager.LayoutParams(chipPx, chipPx, overlayType(),
            baseFlags(false), PixelFormat.TRANSLUCENT)
        p2.gravity = Gravity.TOP or Gravity.START

        c.locked = locked; c2.locked = locked
        c.alpha = Prefs.getInt(this, "alpha_pct", 90) / 100f
        circle = c; chip = c2; cp = p1; lp = p2
        placeChip()
        wm.addView(c, p1); wm.addView(c2, p2)
        wireTouch(c);
        c2.setOnClickListener {
            Prefs.putBool(this, "locked", !Prefs.getBool(this, "locked", false))
            buzz(); applyPrefs(); notifyFg()
        }
    }

    private fun placeChip() {
        val p1 = cp ?: return; val p2 = lp ?: return
        p2.x = (p1.x + p1.width - dp(8)).coerceAtLeast(0)
        p2.y = (p1.y - dp(10)).coerceAtLeast(0)
    }

    private fun wireTouch(v: CircleView) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            val p1 = cp ?: return@setOnTouchListener false
            if (Prefs.getBool(this, "locked", false)) return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p1.x; sy = p1.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (abs(mx) > slop || abs(my) > slop) moved = true
                    if (moved) {
                        p1.x = (sx + mx).toInt().coerceAtLeast(0)
                        p1.y = (sy + my).toInt().coerceAtLeast(0)
                        placeChip()
                        wm.updateViewLayout(v, p1)
                        chip?.let { wm.updateViewLayout(it, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.putInt(this, "cx", p1.x); Prefs.putInt(this, "cy", p1.y)
                    } else {
                        v.pulse(); buzz()
                        Thread {
                            val r = Tools.gameToggle(this).lineSequence().first()
                            v.post { Toast.makeText(this, "VNX: $r", Toast.LENGTH_SHORT).show() }
                        }.start()
                    }
                }
            }
            true
        }
    }

    private fun applyPrefs() {
        val c = circle ?: return; val p1 = cp ?: return; val c2 = chip ?: return
        val locked = Prefs.getBool(this, "locked", false)
        val px = dp(size())
        p1.width = px; p1.height = px
        p1.flags = baseFlags(locked)
        c.locked = locked; c2.locked = locked
        c.alpha = Prefs.getInt(this, "alpha_pct", 90) / 100f
        placeChip()
        wm.updateViewLayout(c, p1)
        wm.updateViewLayout(c2, lp)
    }

    private fun removeViews() {
        try { circle?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { chip?.let { wm.removeView(it) } } catch (_: Exception) {}
        circle = null; chip = null; cp = null; lp = null
    }

    private fun buzz() {
        val v = getSystemService(Vibrator::class.java)
        v?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun pi(action: String, code: Int): PendingIntent =
        PendingIntent.getService(this, code, Intent(this, FloatingService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun notifyFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "VNX Circle", NotificationManager.IMPORTANCE_LOW))
        val locked = Prefs.getBool(this, "locked", false)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("VNX Circle is ON")
            .setContentText(if (locked) "Locked: touches pass through" else "Unlocked: drag to move")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_lock_lock),
                if (locked) "UNLOCK" else "LOCK", pi(ACT_TOGGLE_LOCK, 1)).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "STOP", pi(ACT_STOP, 2)).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NID, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
