package com.vnx.gamehub

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var console: TextView
    private lateinit var timerChip: TextView
    private lateinit var circleCard: NeonCard
    private lateinit var lockCard: NeonCard
    private var typer: Runnable? = null
    private var countdown: CountDownTimer? = null
    private var touchesOn = false
    private var cardIndex = 0

    private class Tool(val glyph: String, val title: String, val sub: String,
                        val accent: Int, val action: () -> Unit)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        root.addView(AnimeBackgroundView(this), FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(40))
        }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        buildHeader(col)
        buildConsole(col)
        buildCirclePanel(col)
        buildTools(col)
        refreshCircleCards()

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        say("VNX GAME HUB 4.0 ready.\nGrant permissions below, then use the circle or the tools.")
    }

    override fun onResume() { super.onResume(); refreshCircleCards() }

    // ---------- sections ----------

    private fun buildHeader(col: LinearLayout) {
        val title = ShimmerText(this).apply {
            text = "VNX GAME HUB"; textSize = 32f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.08f; setTextColor(Color.WHITE)
        }
        val sub = TextView(this).apply {
            text = "ANIME EDITION  -  v4.0"; textSize = 11f; letterSpacing = 0.3f
            setTextColor(Theme.PINK); setPadding(dp(2), dp(2), 0, dp(10))
        }
        timerChip = TextView(this).apply {
            text = "TIMER: IDLE"; textSize = 11f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(6), dp(12), dp(6)); letterSpacing = 0.1f
            background = GradientDrawable().apply {
                cornerRadius = dpf(20f); setColor(Color.parseColor("#33FFFFFF"))
                setStroke(dp(1), Theme.CYAN)
            }
        }
        col.addView(title); col.addView(sub)
        col.addView(timerChip, LinearLayout.LayoutParams(-2, -2))
        enter(title, 0); enter(timerChip, 2)
    }

    private fun buildConsole(col: LinearLayout) {
        console = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(Theme.GREEN)
            minLines = 6; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dpf(16f); setColor(Color.parseColor("#CC050310"))
                setStroke(dp(1), Color.parseColor("#5522D3EE"))
            }
        }
        col.addView(sectionLabel(this, "CONSOLE"))
        col.addView(console, LinearLayout.LayoutParams(-1, -2))
        enter(console, 3)
    }

    private fun buildCirclePanel(col: LinearLayout) {
        col.addView(sectionLabel(this, "FLOATING CIRCLE"))
        circleCard = neonCard(this, "O", "CIRCLE", "OFF", Theme.PINK)
        lockCard = neonCard(this, "L", "LOCK", "UNLOCKED", Theme.GOLD)
        circleCard.root.setOnClickListener { toggleCircle() }
        lockCard.root.setOnClickListener { toggleLock() }
        col.addView(row(circleCard.root, lockCard.root))
        col.addView(seek("SIZE", 40, 120, Prefs.getInt(this, "size_dp", 64), "size_dp"))
        col.addView(seek("OPACITY", 20, 100, Prefs.getInt(this, "alpha_pct", 90), "alpha_pct"))
        val hint = TextView(this).apply {
            text = "Place the circle where you want, then press LOCK. Locked circle stops moving " +
                "and lets your touches pass through to the game underneath."
            textSize = 11f; setTextColor(Color.parseColor("#A99CC8")); setPadding(dp(4), dp(8), dp(4), 0)
        }
        col.addView(hint)
    }

    private fun buildTools(col: LinearLayout) {
        val tools = listOf(
            Tool("▶", "GAME MODE ON", "DND + max brightness", Theme.GREEN) { bg { Tools.gameOn(this) } },
            Tool("■", "GAME MODE OFF", "restore everything", Theme.RED) { bg { Tools.gameOff(this) } },
            Tool("⚡", "BOOST", "animation 0.5x", Theme.GOLD) { bg { Tools.boost(this, true) } },
            Tool("↺", "RESET", "animation 1.0x", Theme.CYAN) { bg { Tools.boost(this, false) } },
            Tool("◉", "TOUCHES", "show touch points", Theme.PINK) {
                touchesOn = !touchesOn; val on = touchesOn; bg { Tools.touches(this, on) } },
            Tool("✚", "SYSTEM CHECK", "RAM, battery, ping", Theme.CYAN) { bg { Tools.system(this) } },
            Tool("≋", "NETWORK", "3 server ping test", Theme.PURPLE) { bg { Tools.network() } },
            Tool("★", "SENSI", "tap view, hold edit", Theme.PINK) { say(Tools.sensi(this)) },
            Tool("▷", "SESSION START", "start play log", Theme.GREEN) { say(Tools.sessionStart(this)) },
            Tool("Σ", "SESSION STATS", "time played", Theme.CYAN) { say(Tools.sessionStats(this)) },
            Tool("◼", "SESSION END", "save to log", Theme.RED) { say(Tools.sessionEnd(this)) },
            Tool("5", "TRAIN 5 MIN", "training timer", Theme.GOLD) { startTimer(5, "TRAINING") },
            Tool("10", "BREAK 10 MIN", "rest timer", Theme.PURPLE) { startTimer(10, "BREAK") },
            Tool("✖", "STOP TIMER", "cancel running timer", Theme.RED) { stopTimer() }
        )
        col.addView(sectionLabel(this, "TOOLS"))
        addGrid(col, tools)

        val perms = listOf(
            Tool("◎", "OVERLAY", "draw over apps", Theme.PINK) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) },
            Tool("⚙", "SETTINGS", "modify system settings", Theme.GOLD) {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) },
            Tool("☾", "DND ACCESS", "do not disturb", Theme.CYAN) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        )
        col.addView(sectionLabel(this, "PERMISSIONS"))
        addGrid(col, perms)

        val adb = TextView(this).apply {
            text = "Boost and Touches need a one-time ADB grant:\n" +
                "adb shell pm grant com.vnx.gamehub android.permission.WRITE_SECURE_SETTINGS"
            textSize = 10f; typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#A99CC8")); setPadding(dp(4), dp(12), dp(4), 0)
            setTextIsSelectable(true)
        }
        col.addView(adb)
    }

    // ---------- helpers ----------

    private fun addGrid(col: LinearLayout, items: List<Tool>) {
        var i = 0
        while (i < items.size) {
            val a = card(items[i]); val b2 = if (i + 1 < items.size) card(items[i + 1]) else View(this)
            col.addView(row(a, b2))
            i += 2
        }
    }

    private fun card(t: Tool): View {
        val c = neonCard(this, t.glyph, t.title, t.sub, t.accent)
        c.root.setOnClickListener { t.action() }
        if (t.title == "SENSI") c.root.setOnLongClickListener { editSensi(); true }
        return c.root
    }

    private fun row(a: View, b2: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        val lp = { m: Int -> LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(if (m == 0) 0 else 5), dp(5), dp(if (m == 0) 5 else 0), dp(5)) } }
        addView(a, lp(0)); addView(b2, lp(1))
        enter(a, cardIndex++); enter(b2, cardIndex++)
    }

    private fun seek(label: String, min: Int, max: Int, cur: Int, key: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(10), dp(4), 0) }
        val tv = TextView(this).apply { text = "$label: $cur"; textSize = 11f; setTextColor(Color.WHITE) }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            progressTintList = ColorStateList.valueOf(Theme.PINK)
            thumbTintList = ColorStateList.valueOf(Theme.CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tv.text = "$label: ${p + min}"
                    if (fromUser) { Prefs.putInt(this@MainActivity, key, p + min); pushUpdate() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(tv); box.addView(sb)
        return box
    }

    private fun bg(job: () -> String) {
        say("working...")
        Thread {
            val r = try { job() } catch (e: Exception) { "[X] ${e.message}" }
            ui.post { say(r) }
        }.start()
    }

    private fun say(text: String) {
        typer?.let { ui.removeCallbacks(it) }
        val full = "> $text"
        console.text = ""
        var n = 0
        val r = object : Runnable {
            override fun run() {
                n = minOf(full.length, n + 3)
                console.text = full.substring(0, n)
                if (n < full.length) ui.postDelayed(this, 12)
            }
        }
        typer = r
        ui.post(r)
    }

    // ---------- circle ----------

    private fun toggleCircle() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Draw over other apps' first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Prefs.getBool(this, "circle_on", false)) {
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_STOP))
            Prefs.putBool(this, "circle_on", false)
        } else {
            startForegroundService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_START))
            Prefs.putBool(this, "circle_on", true)
        }
        refreshCircleCards()
    }

    private fun toggleLock() {
        Prefs.putBool(this, "locked", !Prefs.getBool(this, "locked", false))
        pushUpdate(); refreshCircleCards()
        buzz()
    }

    private fun pushUpdate() {
        if (Prefs.getBool(this, "circle_on", false))
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_UPDATE))
    }

    private fun refreshCircleCards() {
        circleCard.sub.text = if (Prefs.getBool(this, "circle_on", false)) "ON - tap to stop" else "OFF - tap to start"
        circleCard.sub.setTextColor(if (Prefs.getBool(this, "circle_on", false)) Theme.GREEN else Color.parseColor("#A99CC8"))
        val l = Prefs.getBool(this, "locked", false)
        lockCard.sub.text = if (l) "LOCKED - click-through" else "UNLOCKED - draggable"
        lockCard.sub.setTextColor(if (l) Theme.GOLD else Color.parseColor("#A99CC8"))
    }

    private fun buzz() {
        getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    // ---------- timer / sensi ----------

    private fun startTimer(min: Int, label: String) {
        countdown?.cancel()
        countdown = object : CountDownTimer(min * 60_000L, 1000L) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                timerChip.text = "$label  %02d:%02d".format(s / 60, s % 60)
            }
            override fun onFinish() {
                timerChip.text = "TIMER: DONE"
                say("$label finished.")
                getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        }.start()
        say("$label timer started: $min min")
    }

    private fun stopTimer() {
        countdown?.cancel(); countdown = null
        timerChip.text = "TIMER: IDLE"
        say("Timer stopped.")
    }

    private fun editSensi() {
        val et = EditText(this).apply {
            setText(Prefs.getStr(this@MainActivity, "sensi", Prefs.DEFAULT_SENSI))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            gravity = Gravity.TOP; minLines = 8; typeface = Typeface.MONOSPACE
        }
        AlertDialog.Builder(this)
            .setTitle("Sensi presets (Name=Value per line)")
            .setView(et)
            .setPositiveButton("SAVE") { _, _ ->
                Prefs.putStr(this, "sensi", et.text.toString()); say(Tools.sensi(this))
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    override fun onDestroy() {
        countdown?.cancel()
        typer?.let { ui.removeCallbacks(it) }
        super.onDestroy()
    }
}
